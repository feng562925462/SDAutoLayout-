//
//  TwoViewController.m
//  SDAutoLayout
//
//  Created by admin on 16/7/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "TwoViewController.h"
#import <SDAutoLayout.h>

@interface TwoViewController ()


@end

@implementation TwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.navigationItem.title = @"SDAutoLayout实现界面的平分";
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIView *bgView = [[UIView alloc] init];
    bgView.backgroundColor = [UIColor grayColor];
    [self.view addSubview:bgView];
    
    bgView.sd_layout
    .centerXEqualToView(self.view)
    .centerYEqualToView(self.view)
    .widthRatioToView(self.view,1)
    .heightIs(100);
    
    NSMutableArray *temp = [NSMutableArray new];
    for (int i = 0; i < 3; i++) {
        UIView *view = [UIView new];
        view.backgroundColor = [self randomColor];
        [bgView addSubview:view];
        view.sd_layout.autoHeightRatio(1); // 高度是宽度的n倍,如果高度大于背景视图的高，背景视图会跟着改变
//        view.sd_layout.heightIs(50); // 设置高度固定为多少
        [temp addObject:view];
    }

//    // 关键步骤：设置类似collectionView的展示效果
    /**
     * 设置类似collectionView效果的固定间距自动宽度浮动子view
     * viewsArray       : 需要浮动布局的所有视图
     * perRowItemsCount : 每行显示的视图个数
     * verticalMargin   : 视图之间的垂直间距
     * horizontalMargin : 视图之间的水平间距
     * vInset           : 上下缩进值
     * hInset           : 左右缩进值
     */
    [bgView setupAutoWidthFlowItems:[temp copy] withPerRowItemsCount:3 verticalMargin:10 horizontalMargin:10 verticalEdgeInset:5 horizontalEdgeInset:5];
}

- (UIColor *)randomColor
{
    CGFloat r = arc4random_uniform(256) / 255.0;
    CGFloat g = arc4random_uniform(256) / 255.0;
    CGFloat b = arc4random_uniform(256) / 255.0;
    
    return [UIColor colorWithRed:r green:g blue:b alpha:1];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
