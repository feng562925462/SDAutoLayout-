//
//  PhotosContainerView.h
//  SDAutoLayout
//
//  Created by admin on 16/7/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotosContainerView : UIView

- (instancetype)initWithMaxItemsCount:(NSInteger)count;

@property (nonatomic,strong) NSArray *photoNamesArray;

@property (nonatomic ,assign) NSInteger maxItemsCount; // 最大数量

@end
