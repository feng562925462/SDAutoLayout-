//
//  ViewController.m
//  SDAutoLayout
//
//  Created by admin on 16/7/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "ViewController.h"
#import <SDAutoLayout.h>

@interface ViewController ()

@property (nonatomic, strong) UIView *view0;
@property (nonatomic, strong) UIView *view1;
@property (nonatomic, strong) UIView *view2;
@property (nonatomic, strong) UIView *view3;

@property (nonatomic,strong) UIScrollView  * scrollView;

@end

@implementation ViewController

- (UIView *)view0 {
    if (!_view0) {
        _view0 = [[UIView alloc] init];
        _view0.backgroundColor = [UIColor redColor];
        [self.view addSubview:_view0];
    }
    return _view0;
}

- (UIView *)view1 {
    if (!_view1) {
        _view1 = [[UIView alloc] init];
        _view1.backgroundColor = [UIColor blueColor];
        [self.view addSubview:_view1];
    }
    return _view1;
}

- (UIView *)view2 {
    if (!_view2) {
        _view2 = [[UIView alloc] init];
        _view2.backgroundColor = [UIColor brownColor];
        [self.view addSubview:_view2];
    }
    return _view2;
}
- (UIView *)view3 {
    if (!_view3) {
        _view3 = [[UIView alloc] init];
        _view3.backgroundColor = [UIColor grayColor];
        [self.view addSubview:_view3];
    }
    return _view3;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"SDAutoLayout基本使用";
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.scrollView = [[UIScrollView alloc] init];
    [self.view addSubview:self.scrollView];
    
    [_scrollView sd_addSubviews:@[self.view0, self.view1, self.view2, self.view3]];
    
    
    _scrollView.sd_layout.spaceToSuperView(UIEdgeInsetsZero);
    
    
    /**
     *  设置view0
     *
     *  左右顶部到scrollView的间距为20
     *
     *  高度等于150
     */
    self.view0.sd_layout
    .leftSpaceToView(_scrollView, 20)
    .rightSpaceToView(_scrollView, 20)
    .topSpaceToView(_scrollView, 20)
    .heightIs(150);
    
    /**
     *  设置view1
     *
     *  顶部到view0的间距为20
     *
     *  中心点x值等于scrollView的中心点x值
     *
     *  高度宽度等于200
     */
    self.view1.sd_layout
    .widthIs(200)
    .heightIs(200)
    .centerXEqualToView(_scrollView)
    .topSpaceToView(self.view0, 20);
    
    /**
     *  设置view2
     *
     *  顶部到view1的间距为20
     *
     *  左右两边到scrollView的间距为50
     *
     *  高度宽度等于150
     */
    self.view2.sd_layout
    .leftSpaceToView(_scrollView, 50)
    .rightSpaceToView(_scrollView, 50)
    .topSpaceToView(self.view1, 20)
    .heightIs(150);
    
    /**
     *  设置view2
     *
     *  顶部到view2的间距为20
     *
     *  中心点x值等于scrollView的中心点x值
     *
     *  高度等于宽度
     *
     *  宽度等于250
     */
    self.view3.sd_layout
    .widthIs(250)
    .heightEqualToWidth()
    .centerXEqualToView(_scrollView)
    .topSpaceToView(self.view2, 20);
    
    // scrollview自动contentsize
    [_scrollView setupAutoContentSizeWithBottomView:self.view3 bottomMargin:20];
    
    // 设置圆角
    self.view0.sd_cornerRadiusFromHeightRatio = @(0.5); // 设置view0的圆角半径为自身高度的0.5倍
    self.view1.sd_cornerRadiusFromWidthRatio = @(0.5);
    self.view2.sd_cornerRadiusFromWidthRatio = @(0.5);
    self.view3.sd_cornerRadiusFromHeightRatio = @1;
}

@end
