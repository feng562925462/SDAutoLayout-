//
//  FourDataModel.h
//  SDAutoLayout
//
//  Created by admin on 16/7/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FourDataModel : NSObject

@property (nonatomic, copy) NSString *iconImagePath;
@property (nonatomic, copy) NSString *title;

@property (nonatomic, strong) NSArray *imagePathsArray;

@end
