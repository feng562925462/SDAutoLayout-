//
//  FourTableViewCell.h
//  SDAutoLayout
//
//  Created by admin on 16/7/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FourDataModel.h"

@interface FourTableViewCell : UITableViewCell

@property (nonatomic,strong) FourDataModel  * model;

@end
