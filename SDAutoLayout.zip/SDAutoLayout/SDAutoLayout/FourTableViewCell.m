//
//  FourTableViewCell.m
//  SDAutoLayout
//
//  Created by admin on 16/7/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "FourTableViewCell.h"
#import <SDAutoLayout.h>
#import "PhotosContainerView.h"

@interface FourTableViewCell ()

@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;

@property (weak, nonatomic) IBOutlet UILabel *contentLabel;

@property (nonatomic,strong) PhotosContainerView *photoView;

@end

@implementation FourTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    _photoView =[[PhotosContainerView alloc] initWithMaxItemsCount:20];
    [self.contentView addSubview:_photoView];
    
    self.contentLabel.font = [UIFont systemFontOfSize:15];
    self.contentLabel.textColor = [UIColor grayColor];
    
    // 头像的约束
    self.iconImageView.sd_layout
    .leftSpaceToView(self.contentView,10)
    .topSpaceToView(self.contentView,10)
    .widthIs(50).heightEqualToWidth();
    
    // 内容label
    self.contentLabel.sd_layout
    .leftSpaceToView(self.iconImageView,10)
    .topEqualToView(self.iconImageView)
    .rightSpaceToView(self.contentView,10)
    .autoHeightRatio(0);
    
    // 图片的约束
    _photoView.sd_layout
    .leftEqualToView(self.contentLabel)
    .rightEqualToView(self.contentLabel)
    .topSpaceToView(self.contentLabel,10);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setModel:(FourDataModel *)model {
    _model = model;
    
    NSMutableArray *temp = [NSMutableArray array];
    [temp addObject:self.iconImageView];
    [temp addObject:self.contentLabel];
    
    self.iconImageView.image = [UIImage imageNamed:model.iconImagePath];
    self.contentLabel.text = model.title;
    
    if (model.imagePathsArray.count) {
        _photoView.photoNamesArray = model.imagePathsArray;
        [temp addObject:_photoView];
    }
    _photoView.hidden = !model.imagePathsArray.count;
    
    [self setupAutoHeightWithBottomViewsArray:temp bottomMargin:10];
}

@end
