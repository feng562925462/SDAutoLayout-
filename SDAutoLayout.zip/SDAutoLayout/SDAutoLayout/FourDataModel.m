//
//  FourDataModel.m
//  SDAutoLayout
//
//  Created by admin on 16/7/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "FourDataModel.h"

@implementation FourDataModel

@end
