//
//  ListViewController.m
//  SDAutoLayout
//
//  Created by admin on 16/7/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "ListViewController.h"
#import <SDAutoLayout.h>
#import "ViewController.h"
#import "TwoViewController.h"
#import "ThreeViewController.h"
#import "FourViewController.h"

@interface ListViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) NSMutableArray  * dataMuArray;

@end

@implementation ListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"SDAutoLayout使用";
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.tableView.sd_layout.spaceToSuperView(UIEdgeInsetsMake(64, 0, 0, 0));
}

/**
 *  　　方法名中带有“SpaceToView”的需要传递2个参数：（UIView）参照view 和 （CGFloat）间距数值,表示到view的间距
 
 　　　　方法名中带有“RatioToView”的需要传递2个参数：（UIView）参照view 和 （CGFloat）倍数,表示view的宽高的倍数
 
 　　　　方法名中带有“EqualToView”的需要传递1个参数：（UIView）参照view，表示与view在某端对齐
 
 　　　　方法名中带有“Is”的需要传递1个参数：（CGFloat）数值 ，表示是多少
 
 另外：
 1.spaceToSuperView 需要传递1个参数 （UIEdgeInsets） 表示到父视图的间距
 2.updateLayout 主动更新约束
 */

/**
 *  注意点:
 1.控制器内部修改约束：
 　　      view.sd_layout.widthRatioToView(self.view, _widthRatio); //在方法内部更新View要修改的约束条件
          [view updateLayout]; // 调用此方法更新约束
 2.如果是父子关系视图，且更新有动画效果的话，更新父视图约束时，子视图也同样得调用updateLayout方法；
 */

#pragma mark -  dataMuArray
- (NSMutableArray *)dataMuArray
{
    if (!_dataMuArray) {
        
        NSArray *arr = @[@"SDAutoLayout基本使用",
                         @"SDAutoLayout平分界面",
                         @"SDAutoLayoutLabel内容自适应",
                         @"xib的高度自适应"];
        
        _dataMuArray = [NSMutableArray arrayWithArray:arr];
    }
    return _dataMuArray;
}

#pragma mark -  tableview

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        
        _tableView.backgroundColor = [UIColor redColor];
        
        _tableView.dataSource = self;
        _tableView.delegate  = self;
        _tableView.tableFooterView = [[UIView alloc] init];
        [self.view addSubview:_tableView];
    }
    return _tableView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataMuArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *Identifier = @"Identifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Identifier];
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = self.dataMuArray[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    ViewController *VC = [[ViewController alloc] init];
    TwoViewController *twoVC = [[TwoViewController alloc] init];
    ThreeViewController *threeVC = [[ThreeViewController alloc] init];
    FourViewController *fourVC = [[FourViewController alloc] init];
    switch (indexPath.row) {
        case 0:
            [self.navigationController pushViewController:VC animated:YES];
            break;
        case 1:
            [self.navigationController pushViewController:twoVC animated:YES];
            break;
        case 2:
            [self.navigationController pushViewController:threeVC animated:YES];
            break;
        case 3:
            [self.navigationController pushViewController:fourVC animated:YES];
            break;
        default:
            break;
    }
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
