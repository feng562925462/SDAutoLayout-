//
//  FourViewController.m
//  SDAutoLayout
//
//  Created by admin on 16/7/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "FourViewController.h"
#import "FourDataModel.h"
#import "FourTableViewCell.h"
#import <SDAutoLayout.h>

@interface FourViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) NSMutableArray  * dataMuArray;

@end

@implementation FourViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor whiteColor];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"FourTableViewCell" bundle:nil] forCellReuseIdentifier:@"FourTableViewCell"];
    
    self.tableView.sd_layout.spaceToSuperView(UIEdgeInsetsZero);
}


#pragma mark -  dataMuArray
- (NSMutableArray *)dataMuArray
{
    if (!_dataMuArray) {
        _dataMuArray = [NSMutableArray array];
        
        NSArray *textArray = @[@"当你的 app 没有提供 3x 的LaunchImage 时。然后等比例拉伸屏幕宽度返回 320；然后等比例拉伸到大屏。这种情况下对界面不会产生任小。但是建议不要长期处于这种模式下，否则在大屏上会显得字大，内容少，容易遭到用户投诉。但是建议不要长期处于这种模式下，否则在大屏上会显得字大，内容少，容易遭到用户投诉。",
                               @"然后等比例拉伸到大屏。屏幕宽度返回 320否则在大屏上会显得字大长期处于这种模式下，否则在大屏上会显得字大，内容少这种情况下对界面不会",
                               @"长期处于这种模式下，否则在大屏上会显得字大，内容少这种情况下对界面不会但是建议不要长期处于这种模式下，否则在大屏上会显得字大，内容少，容易遭到用户投诉。",
                               @"但是建议不要长期处于这种模式下，否则在大屏上会显得字大，内容少，容易遭到用户投诉。",
                               @"屏幕宽度返回 320；然后等比例拉伸到大屏。这种情况下对界面不会产生任小。但是建议不要长期处于这种模式下，否则在大屏上会显得字大，内容少，容易遭到用户投诉。但是建议不要长期处于这种模式下，否则在大屏上会显得字大，内容少，容易遭到用户投诉。但是建议不要长期处于这种模式下，否则在大屏上会显得字大，内容少，容易遭到用户投诉。"
                               ];

        for (int i = 0; i < 20; i++) {
            
            int nameRandomIndex = arc4random_uniform(5);
            
            FourDataModel *model = [[FourDataModel alloc] init];
            model.title = textArray[nameRandomIndex];
            model.iconImagePath = [NSString stringWithFormat:@"%d.jpg",arc4random_uniform(24)];
            
            // 模拟“有或者无图片”
            int random = arc4random_uniform(1);
            if (random < 1) {
                NSMutableArray *temp = [NSMutableArray new];
                
                int randomImagesCount = arc4random_uniform(24);
                for (int i = 0; i < randomImagesCount; i++) {
                    NSString *text = [NSString stringWithFormat:@"%d.jpg",arc4random_uniform(24)];
                    [temp addObject:text];
                }
                
                model.imagePathsArray = [temp copy];
            }
            
            [_dataMuArray addObject:model];
        }

    }
    return _dataMuArray;
}

#pragma mark -  tableview

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate  = self;
        
        [self.view addSubview:_tableView];
    }
    return _tableView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataMuArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FourTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FourTableViewCell"];
    
    cell.model = self.dataMuArray[indexPath.row];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return [self cellHeightForIndexPath:indexPath cellContentViewWidth:[self cellContentViewWith] tableView:tableView];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (CGFloat)cellContentViewWith
{
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    
    // 适配ios7横屏
    if ([UIApplication sharedApplication].statusBarOrientation != UIInterfaceOrientationPortrait && [[UIDevice currentDevice].systemVersion floatValue] < 8) {
        width = [UIScreen mainScreen].bounds.size.height;
    }
    return width;
}

@end
