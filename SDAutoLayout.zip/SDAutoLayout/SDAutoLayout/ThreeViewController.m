//
//  ThreeViewController.m
//  SDAutoLayout
//
//  Created by admin on 16/7/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "ThreeViewController.h"
#import <SDAutoLayout.h>

@interface ThreeViewController ()

@property (nonatomic,strong) UILabel  * label;

@end

@implementation ThreeViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.navigationItem.title = @"SDAutoLayoutLabel内容自适应";
    self.view.backgroundColor = [UIColor whiteColor];
    
    
    self.label = [[UILabel alloc] init];
    self.label.backgroundColor = [UIColor grayColor];
    [self.view addSubview:self.label];
    
    self.label.text = @"方法名中带有“SpaceToView”的需要传递2个参数：（UIView）参照view 和 （CGFloat）间距数值,表示到view的间距方法名中带有“RatioToView”的需要传递2个参数：（UIView）参照view 和 （CGFloat）倍数,表示view的宽高的倍数方法名中带有“EqualToView”的需要传递1个参数：（UIView）参照view，表示与view在某端对齐方法名中带有“Is”的需要传递1个参数：（CGFloat）数值 ，表示是多少另外：1.spaceToSuperView 需要传递1个参数 （UIEdgeInsets） 表示到父视图的间距2.updateLayout 主动更新约束";
    
    self.label.sd_layout
    .leftSpaceToView(self.view,10)
    .topSpaceToView(self.view,100)
    .rightSpaceToView(self.view,20)
    .autoHeightRatio(0);
}




@end
