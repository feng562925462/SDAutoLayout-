//
//  PhotosContainerView.m
//  SDAutoLayout
//
//  Created by admin on 16/7/26.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "PhotosContainerView.h"
#import <SDAutoLayout.h>

@interface PhotosContainerView ()

@property (nonatomic,strong) NSMutableArray  * dataArray; //存储imageView对象
@end

@implementation PhotosContainerView

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (instancetype)initWithMaxItemsCount:(NSInteger)count
{
    self = [super init];
    if (self) {
        self.maxItemsCount = count;
    }
    return self;
}

- (void)setPhotoNamesArray:(NSArray *)photoNamesArray {
    _photoNamesArray = photoNamesArray;
    
    NSInteger needsToAddItemsCount = _photoNamesArray.count - self.dataArray.count;
    
    if (needsToAddItemsCount > 0) {
        for (int i = 0; i < needsToAddItemsCount; i++) {
            UIImageView *imageView = [[UIImageView alloc] init];
            [self addSubview:imageView];
            [self.dataArray addObject:imageView];
        }
    }
    
    NSMutableArray *temp = [NSMutableArray array];
    [self.dataArray enumerateObjectsUsingBlock:^(UIImageView * obj, NSUInteger idx, BOOL *  stop) {
        
        if (idx < _photoNamesArray.count) {
            obj.hidden = NO;
            obj.sd_layout.autoHeightRatio(1);
            obj.image = [UIImage imageNamed:_photoNamesArray[idx]];
            [temp addObject:obj];
        } else {
            [obj sd_clearAutoLayoutSettings];
            obj.hidden = YES;
        }
    }];
    
    //设置界面自动布局的配置
    [self setupAutoWidthFlowItems:temp withPerRowItemsCount:3 verticalMargin:10 horizontalMargin:10 verticalEdgeInset:0 horizontalEdgeInset:0];
}

@end
